<img src="https://i.imgur.com/jZG5MNO.jpg" height="200">

## **Q**uantum Mechanically augmented molecular **force** fields

Please find the examples for Q-Force [here](https://github.com/selimsami/qforce_examples).


